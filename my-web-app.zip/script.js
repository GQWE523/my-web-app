$(".calculator").addClass("pre-enter");
setTimeout(function(){
  $(".calculator").addClass("on-enter");
}, 500);
setTimeout(function(){
  $(".calculator").removeClass("pre-enter on-enter");
}, 2000);

var $keys = $('button');
var $total = $('.total');
var $summary = $('.summary');
var decimal = false;
var operators = ['+', '-', '×', '÷'];

$keys.click(function() {
  var keyVal = $(this).data('val');
  output = $summary.html();
  var lastChar = output[output.length - 1];
  if (keyVal == 'clear') {
    $total.html('0');
    $summary.html('');
    decimal = false;
  }
  else if (keyVal == '=') {
    output = output.replace(/×/g, '*').replace(/÷/g, '/');
    if (operators.indexOf(lastChar) > -1 || lastChar == '.')
      output = output.replace(/.$/, '');
    if (output) {
      $total.html(Math.round(eval(output)*10000000)/10000000);
    }
    $summary.addClass("complete");
    decimal = false;
  }
  else if ($(this).parent().parent().parent().is('.operators')) {
    if ($summary.is(".complete")) {
      $summary.removeClass("complete");
    }
    if (output != '' && operators.indexOf(lastChar) == -1) {
      $summary.html($summary.html() + keyVal);
    } else if (output == '' && keyVal == '-') {
      $summary.html($summary.html() + keyVal);
    }
    if (operators.indexOf(lastChar) > -1 && output.length > 1) {
      $summary.html($summary.html().replace(/.$/, keyVal));
    }
    decimal = false;
  }
  else if (keyVal == '.') {
    if ($summary.is(".complete")) {
      $summary.html('0' + keyVal);
      $summary.removeClass("complete");
    } else if (output == '') {
      $summary.html('0' + keyVal);
    } else if (operators.indexOf(lastChar) > -1) {
      $summary.html($summary.html() + '0' + keyVal);
    } else {
      if (!decimal) {
        $summary.html($summary.html() + keyVal);
        decimal = true;
      }
    }
  }
  else {
    if ($summary.is(".complete")) {
      $summary.html(keyVal);
      $summary.removeClass("complete");
    } else {
      $summary.html($summary.html() + keyVal);
    }
  }
});
